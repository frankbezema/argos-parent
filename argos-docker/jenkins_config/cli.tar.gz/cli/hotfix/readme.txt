Put your hotfix JARs in this directory.

